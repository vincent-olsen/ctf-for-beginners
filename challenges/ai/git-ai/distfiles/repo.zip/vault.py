#!/usr/bin/env python3
"""Seal or open vault.bin.

The key is never committed. It is split into two shares, held by two people,
each 16 bytes of hex: VAULT_SHARE_A and VAULT_SHARE_B (environment variables).
key = A xor B, and the vault is XORed with SHA-256(key || counter) blocks.

    VAULT_SHARE_A=... VAULT_SHARE_B=... python3 vault.py open
    VAULT_SHARE_A=... VAULT_SHARE_B=... python3 vault.py seal < secret.txt
"""
import hashlib
import os
import sys


def keystream(key, n):
    out, i = b"", 0
    while len(out) < n:
        out += hashlib.sha256(key + i.to_bytes(4, "big")).digest()
        i += 1
    return out[:n]


def xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))


def main():
    key = xor(bytes.fromhex(os.environ["VAULT_SHARE_A"]), bytes.fromhex(os.environ["VAULT_SHARE_B"]))
    if sys.argv[1:] == ["seal"]:
        data = sys.stdin.buffer.read()
        with open("vault.bin", "wb") as f:
            f.write(xor(data, keystream(key, len(data))))
    elif sys.argv[1:] == ["open"]:
        with open("vault.bin", "rb") as f:
            data = f.read()
        sys.stdout.buffer.write(xor(data, keystream(key, len(data))))
    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
